#include "model.h"

int main() {
    init();
    run();
    return 0;
}
