#pragma once

#include "common.h"
#include <vector>
#include <map>

struct Cell {
    uchar state;
    uchar weight;

    Cell() {}
    Cell(uchar s, uchar w) : state(s), weight(w) {}

    int getWeight() { return __builtin_popcount(state)+weight; }
};

extern const int field_width, field_height;
extern Cell *cur_iteration, *next_iteration;

void doBarrier(int row, int col);
void doShift(int row, int col);
void doImpact(Cell *cell);

Cell generateCell(int state_weight, int weight);
Cell generateCell(int sum_weight);

void calcEqualClasses();
