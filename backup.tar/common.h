#pragma once

#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <algorithm>

using namespace std;

typedef unsigned char uchar;
